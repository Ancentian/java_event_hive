<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$route['default_controller'] = "Auth";
$route['404_override'] = 'E404';


/* End of file routes.php */
/* Location: ./application/config/routes.php */