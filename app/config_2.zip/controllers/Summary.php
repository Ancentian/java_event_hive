<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Summary extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('production_model', 'production');
        $this->load->model('products_model', 'products');
        $this->load->model('customers_model', 'customers');
        $this->load->model('collection_model', 'collection');
        $this->load->model('reports_model', 'reports');
        $this->load->model('summary_model', 'summary');
        $this->load->model('employee_model');
        $this->load->model('send_message');
    }

    public function sendSummary()
    {
        $todaySales = $this->summary->fetch_todaysIncome();//paid
        $todaysProduction = $this->summary->all_productions_today();
        //var_dump($todaysProduction);die;
        $paidUnpaid = $this->summary->total_incomeProductions();//Total Income(Paid&UnPaid) since Prod Started
        $totalIncome = $this->summary->total_income();//Total Income(Paid) since Production Started
        //var_dump($paidUnpaid);die;
        $totalDue = $paidUnpaid - $totalIncome;
        //$tot = $todaySales + $totalIncome;

        //var_dump($tot);die;
        $time = date("h:i:sa");
        //$tm = "06:36:02pm";

        $smsadmins = $this->employee_model->fetch_admin();
        $rec = $smsadmins['recipients'];
        
         $msg = "AUTOMATED DAILY REPORTS
Embroidery
Today's Income $todaySales

GRAND TOTALS:
Total Income $paidUnpaid
Outstanding Debts: $totalDue
Paid Debts $totalIncome";
//var_dump($msg);die;

        $this->send_message->send($msg, $rec);
    }

	
}
